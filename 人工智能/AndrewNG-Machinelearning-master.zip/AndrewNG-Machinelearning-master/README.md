# AndrewNG-Machinelearning
斯坦福吴恩达教授在Coursera上的机器学习课程的课件，作业及鄙人的笔记。
